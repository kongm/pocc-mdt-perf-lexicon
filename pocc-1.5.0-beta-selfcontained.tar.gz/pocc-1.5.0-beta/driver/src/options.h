/*
 * options.h: this file is part of the PoCC project.
 *
 * PoCC, the Polyhedral Compiler Collection package
 *
 * Copyright (C) 2009 Louis-Noel Pouchet
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * The complete GNU General Public Licence Notice can be found as the
 * `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#ifndef POCC_SRC_OPTIONS_H
# define POCC_SRC_OPTIONS_H

# include <stdio.h>

# if HAVE_CONFIG_H
#  include <pocc-utils/config.h>
# endif

# include <pocc/options.h>
# include "getopts.h"

# ifdef POCC_DEVEL_MODE
#  define POCC_NB_OPTS				128
# else
#  define POCC_NB_OPTS				116
# endif

# define POCC_OPT_HELP				0
# define POCC_OPT_VERSION			1
# define POCC_OPT_OUTFILE			2
# define POCC_OPT_OUTFILE_SCOP			3
# define POCC_OPT_CLOOGIFY_SCHED       		4
# define POCC_OPT_BOUNDED_CTXT	       		5
# define POCC_OPT_DEFAULT_CTXT	       		6
# define POCC_OPT_USER_CTXT	       		7
# define POCC_OPT_PREPROCESS	       		8
# define POCC_OPT_PREPROCESS_PARAMETERIZE_SLACK 9
# define POCC_OPT_INSCOP_FAKEARRAY		10
# define POCC_OPT_READ_SCOP_FILE		11

# define POCC_OPT_NO_CANDL			12
# define POCC_OPT_CANDL_DEP_ISL_SIMP		13
# define POCC_OPT_CANDL_DEP_PRUNE_DUPS		14

# define POCC_OPT_POLYFEAT			15
# define POCC_OPT_POLYFEAT_LEGACY    		16
# define POCC_OPT_POLYFEAT_AST_STATS   		17
# define POCC_OPT_POLYFEAT_RAR			18
# define POCC_OPT_POLYFEAT_LINESIZE    		19
# define POCC_OPT_POLYFEAT_CACHESIZE   		20
# define POCC_OPT_POLYFEAT_ASSOCIATIVITY	21
# define POCC_OPT_POLYFEAT_CACHE_IS_PRIV  	22
# define POCC_OPT_POLYFEAT_MULTI_PARAMS   	23

# define POCC_OPT_TRASH				24
# define POCC_OPT_VERBOSE			25
# define POCC_OPT_QUIET				26

# define POCC_OPT_LETSEE			27
# define POCC_OPT_LETSEE_SEARCHSPACE		28
# define POCC_OPT_LETSEE_TRAVERSAL		29
# define POCC_OPT_LETSEE_DRY_RUN          	30
# define POCC_OPT_LETSEE_NORMSPACE		31
# define POCC_OPT_LETSEE_BOUNDS			32
# define POCC_OPT_LETSEE_SCHEME_M1		33
# define POCC_OPT_LETSEE_RTRIES			34
# define POCC_OPT_LETSEE_PRUNE_PRECUT		35
# define POCC_OPT_LETSEE_BACKTRACK_MULTI	36

# define POCC_OPT_PLUTO				37
# define POCC_OPT_PLUTO_PARALLEL		38
# define POCC_OPT_PLUTO_TILE			39
# define POCC_OPT_PLUTO_L2TILE			40
# define POCC_OPT_PLUTO_FUSE			41
# define POCC_OPT_PLUTO_UNROLL			42
# define POCC_OPT_PLUTO_UFACTOR			43
# define POCC_OPT_PLUTO_POLYUNROLL		44
# define POCC_OPT_PLUTO_PREVECTOR		45
# define POCC_OPT_PLUTO_MULTIPIPE		46
# define POCC_OPT_PLUTO_RAR			47
# define POCC_OPT_PLUTO_RAR_CF			48
# define POCC_OPT_PLUTO_LASTWRITER		49
# define POCC_OPT_PLUTO_SCALPRIV		50
# define POCC_OPT_PLUTO_BEE			51
# define POCC_OPT_PLUTO_QUIET			52
# define POCC_OPT_PLUTO_FT			53
# define POCC_OPT_PLUTO_LT			54
# define POCC_OPT_PLUTO_EXTERNAL_CANDL	       	55
# define POCC_OPT_PLUTO_TILING_IN_SCATT	       	56
# define POCC_OPT_PLUTO_BOUND_COEF	       	57
# define POCC_OPT_PLUTO_NO_SKEWING	       	58

# define POCC_OPT_NOCODEGEN			59
# define POCC_OPT_CLOOG_F			60
# define POCC_OPT_CLOOG_L			61
# define POCC_OPT_PRINT_CLOOG_FILE		62
# define POCC_OPT_NO_PAST			63
# define POCC_OPT_PAST_OPTIMIZE_LOOP_BOUND	64
# define POCC_OPT_PRAGMATIZER			65

# define POCC_OPT_PTILE				66
# define POCC_OPT_PTILE_FTS    			67
# define POCC_OPT_PTILE_LEVEL			68
# define POCC_OPT_PTILE_EVOLVETILE    		69

# define POCC_OPT_PUNROLL			70
# define POCC_OPT_PUNROLL_AND_JAM      		71
# define POCC_OPT_PUNROLL_SIZE      		72

# define POCC_OPT_VECTORIZER			73
# define POCC_OPT_VECTORIZER_SIMDIZE   		74
# define POCC_OPT_VECTORIZER_SIMDIZE_MV 	75
# define POCC_OPT_VECTORIZER_SIMDIZE_MV_STRAT 	76

# define POCC_OPT_CODEGEN_TIMERCODE		77
# define POCC_OPT_CODEGEN_TIMER_ASM		78
# define POCC_OPT_CODEGEN_TIMER_PAPI		79
# define POCC_OPT_CODEGEN_DINERO		80


# define POCC_OPT_COMPILE			81
# define POCC_OPT_COMPILE_CMD			82
# define POCC_OPT_RUN_CMD_ARGS          	83
# define POCC_OPT_PROGRAM_TIMEOUT        	84

# define POCC_OPT_PONOS				85
# define POCC_OPT_PONOS_QUIET	        	86
# define POCC_OPT_PONOS_DEBUG	        	87
# define POCC_OPT_PONOS_SCHED_DIMENSION		88
# define POCC_OPT_PONOS_COEF_ARE_POS	        89
# define POCC_OPT_PONOS_BUILD_2DP1	        90
# define POCC_OPT_PONOS_SOLVER_TYPE	        91
# define POCC_OPT_PONOS_SOLVER_PRECOND	        92
# define POCC_OPT_PONOS_MAXSCALE_SOLVER		93
# define POCC_OPT_PONOS_NOREDUNDANCY_SOLVER	94
# define POCC_OPT_PONOS_LEGALITY_CONSTANT_K	95
# define POCC_OPT_PONOS_SCHED_COEF_BOUND	96
# define POCC_OPT_PONOS_OBJECTIVE		97
# define POCC_OPT_PONOS_OBJECTIVE_LIST		98
# define POCC_OPT_PONOS_PIPSOLVE_LP		99
# define POCC_OPT_PONOS_PIPSOLVE_GMP		100

# define POCC_OPT_PAST_SUPER_OPT_LOOP_BOUND	101
# define POCC_OPT_READ_CLOOG_FILE		102

# define POCC_OPT_PSIMDKZER			103
# define POCC_OPT_PSIMDKZER_TARGET		104
# define POCC_OPT_PSIMDKZER_VECTOR_ISA		105
# define POCC_OPT_PSIMDKZER_SCALAR_DATATYPE	106
# define POCC_OPT_PSIMDKZER_RESKEW		107
# define POCC_OPT_PSIMDKZER_GEN_POLYBENCH_SCRIPT	108

# define POCC_OPT_SIMD_LENGTH			109
# define POCC_OPT_SIMD_FMA			110
# define POCC_OPT_ELEMENT_SIZE_IN_BYTES		111
# define POCC_OPT_NUM_OMP_THREADS		112

# define POCC_OPT_OUTPUT_APPROXAST_SCOP       	113
# define POCC_OPT_ASTER_OUTPUT		       	114
# define POCC_OPT_INTERPRETER		       	115


# ifdef POCC_DEVEL_MODE
#  define POCC_OPT_STD_LAST_ID 115
/* Devel-only options. */
#  define POCC_OPT_VECT_MARK_PAR_LOOPS    	(POCC_OPT_STD_LAST_ID+1)
#  define POCC_OPT_VECT_NO_KEEP_OUTER_PAR_LOOPS (POCC_OPT_STD_LAST_ID+2)
#  define POCC_OPT_VECT_SINK_ALL_LOOPS		(POCC_OPT_STD_LAST_ID+3)
#  define POCC_OPT_STORCOMPACT			(POCC_OPT_STD_LAST_ID+4)
#  define POCC_OPT_AC_KEEP_OUTERPAR		(POCC_OPT_STD_LAST_ID+5)
#  define POCC_OPT_AC_KEEP_VECTORIZED		(POCC_OPT_STD_LAST_ID+6)
#  define POCC_OPT_CDSCGR			(POCC_OPT_STD_LAST_ID+7)
#  define POCC_OPT_DDGANALYZE			(POCC_OPT_STD_LAST_ID+8)
#  define POCC_OPT_DDGANALYZE_PARAMETERIZE	(POCC_OPT_STD_LAST_ID+9)
#  define POCC_OPT_DDGANALYZE_PRUNE		(POCC_OPT_STD_LAST_ID+10)
#  define POCC_OPT_DDGANALYZE_STATS		(POCC_OPT_STD_LAST_ID+11)
#  define POCC_OPT_DDGANALYZE_MERGE		(POCC_OPT_STD_LAST_ID+12)
#endif

BEGIN_C_DECLS

extern
int
pocc_getopts(s_pocc_options_t* options, int argc, char** argv);

END_C_DECLS

#endif // POCC_SRC_OPTIONS_H
