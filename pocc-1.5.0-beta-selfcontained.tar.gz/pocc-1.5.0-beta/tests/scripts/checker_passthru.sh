#!/bin/sh
## checker.sh for pocc in /Users/pouchet
##
## Made by Louis-Noel Pouchet
## Contact: <louis-noel.pouchet@inria.fr>
##
## Started on  Sat Jul 18 16:57:09 2009 Louis-Noel Pouchet
## Last update Thu Jan 30 16:31:29 2014 Louis-Noel Pouchet
##
./$CHECKER "PoCC (pass-thru)" "$TEST_SUITE" passthru
