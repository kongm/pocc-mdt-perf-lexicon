#!/bin/sh
## checker.sh for pocc in /Users/pouchet
##
## Made by Louis-Noel Pouchet
## Contact: <louis-noel.pouchet@inria.fr>
##
## Started on  Sat Jul 18 16:57:09 2009 Louis-Noel Pouchet
## Last update Sat Jul 18 18:02:18 2009 Louis-Noel Pouchet
##

./$CHECKER "PoCC --pluto-tile" "$TEST_SUITE" tile
